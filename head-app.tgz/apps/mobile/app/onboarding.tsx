import React, { useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated, { FadeIn } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import EntryAccount from '@/components/EntryAccount';
import Chameleon from '@/components/Chameleon';
import { Appear, Button, Card, Divider, Row, T, haptic } from '@/components/ui';
import { C, CONTEXT, S } from '@/theme';
import { LANGS } from '@/i18n';
import { useT } from '@/i18n/useT';
import { useStore } from '@/store';

const SLIDES: { ctx: keyof typeof CONTEXT; t: 'onb.1.title' | 'onb.2.title' | 'onb.3.title'; b: 'onb.1.body' | 'onb.2.body' | 'onb.3.body' }[] = [
  { ctx: 'home', t: 'onb.1.title', b: 'onb.1.body' },
  { ctx: 'mobility', t: 'onb.2.title', b: 'onb.2.body' },
  { ctx: 'food', t: 'onb.3.title', b: 'onb.3.body' },
];

export default function Onboarding() {
  const insets = useSafeAreaInsets();
  const t = useT();
  const { lang, setProfile, setOnboarded, setPrivacy } = useStore();
  const [i, setI] = useState(0);
  const [consent, setConsent] = useState(false);
  const [showLanguages, setShowLanguages] = useState(false);
  const last = i === SLIDES.length; // Gemeinsamer Zugang oder Gastmodus
  const ctx = last ? 'community' : SLIDES[i].ctx;
  const color = CONTEXT[ctx].color;

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <LinearGradient colors={[color + '33', C.bg]} style={{ position: 'absolute', left: 0, right: 0, top: 0, height: 420 }} />
      <ScrollView contentContainerStyle={{ paddingTop: insets.top + 12, paddingHorizontal: S.xl, paddingBottom: insets.bottom + 24, flexGrow: 1, maxWidth: 560, width: '100%', alignSelf: 'center' }} keyboardShouldPersistTaps="handled">
        <View style={{ alignItems: 'flex-end' }}>
          <Pressable accessibilityRole="button" accessibilityLabel={t('data.languages')} accessibilityState={{ expanded: showLanguages }} onPress={() => setShowLanguages((open) => !open)} style={{ width: 42, height: 42, borderRadius: 21, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontSize: 18 }}>🌐</Text>
          </Pressable>
        </View>
        {showLanguages && (
          <Card style={{ marginTop: 8 }}>
            {LANGS.filter((language) => language.code !== 'leicht').map((language, index, languages) => (
              <View key={language.code}>
                <Pressable accessibilityRole="button" accessibilityState={{ selected: lang === language.code }} onPress={() => { setProfile({ lang: language.code }); setShowLanguages(false); }} style={{ paddingVertical: 10 }}>
                  <Row style={{ justifyContent: 'space-between' }}>
                    <Text style={T.body}>{language.flag} {language.label}</Text>
                    {lang === language.code && <Text style={{ color, fontWeight: '900' }}>✓</Text>}
                  </Row>
                </Pressable>
                {index < languages.length - 1 && <Divider />}
              </View>
            ))}
          </Card>
        )}
        <View style={{ alignItems: 'center', marginTop: 28 }}>
          <Chameleon pose={last ? 'cheer' : i % 2 ? 'hello' : 'wave'} size={230} />
        </View>
        <Appear key={i} style={{ marginTop: 24, minHeight: 190 }}>
          {!last ? (
            <>
              {i === 1 && lang === 'de' ? (
                <View>
                  <Text style={T.h1}>{t('data.onbFrankfurt')}</Text>
                  <View style={{ alignItems: 'center', marginTop: 2 }}>
                    <Text style={{ width: '100%', color, fontFamily: 'serif', fontStyle: 'italic', fontSize: 44, lineHeight: 52, fontWeight: '900', letterSpacing: 1, textAlign: 'center', textShadowColor: color + '55', textShadowOffset: { width: 0, height: 3 }, textShadowRadius: 7 }}>Frankfurt.</Text>
                    <View style={{ width: 118, height: 4, marginTop: -2, borderRadius: 2, backgroundColor: color, transform: [{ rotate: '-2deg' }] }} />
                  </View>
                </View>
              ) : (
                <Text style={T.h1}>{t(SLIDES[i].t)}</Text>
              )}
              <Text style={[T.body, { marginTop: 10, fontSize: 17, lineHeight: 25 }]}>{t(SLIDES[i].b)}</Text>
              {i === 2 && (
                <Pressable accessibilityRole="checkbox" accessibilityState={{ checked: consent }} onPress={() => setConsent(!consent)} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 18, backgroundColor: '#fff', padding: 14, borderRadius: 16 }}>
                  <View style={{ width: 26, height: 26, borderRadius: 8, borderWidth: 2, borderColor: color, backgroundColor: consent ? color : '#fff', alignItems: 'center', justifyContent: 'center' }}>{consent && <Text style={{ color: '#fff', fontWeight: '900' }}>✓</Text>}</View>
                  <Text style={[T.body, { flex: 1 }]}>{t('data.consent')}</Text>
                </Pressable>
              )}
            </>
          ) : (
            <EntryAccount initialRegister color={color} onReady={()=>{haptic('success');setPrivacy({shareAggregates:consent});setOnboarded(true);}}/>
          )}
        </Appear>
        <View style={{ flex: 1 }} />
        <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 6, marginBottom: 18 }}>
          {[...SLIDES, null].map((_, k) => <Animated.View key={k} entering={FadeIn} style={{ width: k === i ? 22 : 7, height: 7, borderRadius: 4, backgroundColor: k === i ? color : C.line }} />)}
        </View>
        {!last&&<Button color={color} label={t('common.next')} disabled={i===2&&!consent} onPress={()=>setI(i+1)}/>}
        {i > 0 && !last && <Pressable onPress={() => setI(i - 1)} style={{ alignSelf: 'center', marginTop: 12 }}><Text style={{ color: C.muted, fontWeight: '700' }}>{t('common.back')}</Text></Pressable>}
      </ScrollView>
    </View>
  );
}
