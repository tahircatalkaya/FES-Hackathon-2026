import React, { useCallback, useState } from 'react';
import { AppState, Platform, Text, TextInput, View } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as Location from 'expo-location';
import { trust } from '@/api/trust';
import { CLEANUPS } from '@/data/mock';
import { useStore } from '@/store';
import { useUI } from '@/store/ui';
import { Button, Card, T, Tag } from './ui';
import { Screen, Header } from './Screen';
import ProofCode from './ProofCode';
import { C } from '@/theme';
import { useT, useLocalize } from '@/i18n/useT';
export default function CleanupProof({id,embedded=false}:{id:string;embedded?:boolean}) {
  const t=useT(),l=useLocalize(),own=useStore(s=>s.ownCleanups),activity=[...own,...CLEANUPS].find(c=>c.id===id);
  const [eventId,setEventId]=useState(''),[ticket,setTicket]=useState<{proof:string;expiresAt:number}|null>(null),[confirmed,setConfirmed]=useState(false),[scanning,setScanning]=useState(false),[raw,setRaw]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);
  const [permission,request]=useCameraPermissions();
  const load=useCallback(async()=>{try{if(!activity||!await trust.hasSession())return;const state=await trust.cleanupJoin(activity);setEventId(state.id);setConfirmed(state.confirmed);const me=await trust.me();useStore.getState().syncFoodAwards(me.awards);}catch(e:any){setError(e.message);}},[id]);
  useFocusEffect(useCallback(()=>{void load();const interval=setInterval(()=>{if(AppState.currentState==='active')void load();},10000);return()=>clearInterval(interval);},[load]));
  async function position(){const p=await Location.requestForegroundPermissionsAsync();if(p.status!=='granted')throw new Error(t('updates.locationNeeded'));const at=await Location.getCurrentPositionAsync({accuracy:Location.Accuracy.High});return {lat:at.coords.latitude,lon:at.coords.longitude,accuracy:at.coords.accuracy??999,at:at.timestamp};}
  async function run(scan=false){if(busy||!eventId)return;setBusy(true);setError('');try{const pos=await position();if(!scan)setTicket(await trust.cleanupTicket(eventId,pos));else{await trust.cleanupConfirm(eventId,raw.trim(),pos);setConfirmed(true);setScanning(false);const me=await trust.me();useStore.getState().syncFoodAwards(me.awards);const a=me.awards.find(a=>a.key===`trust:cleanup:${eventId}:${me.user.id}`);if(a)useUI.getState().showToast(a);}}catch(e:any){setError(e.message);}finally{setBusy(false);}}
  const body=<View style={{gap:12}}>
    <Card style={{gap:12}}><Tag label={confirmed?t('updates.participationConfirmed'):t('updates.registeredNoPoints')} color={confirmed?C.success:C.clean}/><Text style={T.body}>{t('updates.cleanupHow')}</Text>
      <Button label={t('updates.showMyQr')} color={C.clean} disabled={busy||!eventId} onPress={()=>void run()}/>
      {ticket&&<ProofCode {...ticket} label={t('updates.showMyQr')}/>}
      {!confirmed&&<Button label={t('updates.scanPeer')} color={C.clean} variant="soft" disabled={!eventId} onPress={()=>setScanning(!scanning)}/>}
      {scanning&&!confirmed&&<View style={{gap:12}}>{Platform.OS!=='web'&&(permission?.granted?<View style={{height:230,borderRadius:18,overflow:'hidden'}}><CameraView style={{flex:1}} barcodeScannerSettings={{barcodeTypes:['qr']}} onBarcodeScanned={e=>{if(!raw)setRaw(e.data);}}/></View>:<Button label={t('updates.camera')} onPress={()=>void request()}/>)}<TextInput accessibilityLabel={t('components.scan.code')} value={raw} onChangeText={setRaw} placeholder="mainsam:cleanup:…" autoCapitalize="none" maxLength={200} style={{padding:12,borderRadius:12,backgroundColor:C.bg,color:C.ink}}/><Button label={t('updates.confirmHere')} color={C.clean} disabled={busy||!raw.trim()} onPress={()=>void run(true)}/></View>}
      {!!error&&<><Text accessibilityRole="alert" style={[T.body,{color:C.danger}]}>{l(error)}</Text>{!eventId&&<Button label={t('components.common.reload')} onPress={()=>void load()}/>}</>}
    </Card>
  </View>;
  return embedded?body:<Screen tabBar={false}><Header title={activity?l(activity.title):t('updates.scanPeer')}/>{body}</Screen>;
}
