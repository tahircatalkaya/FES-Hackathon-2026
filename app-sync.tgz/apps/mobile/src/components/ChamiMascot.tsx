import { useT, useLocalize } from '@/i18n/useT';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { AppState, Image, Modal, Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import Animated, { Easing, FadeIn, ZoomIn, useAnimatedStyle, useSharedValue, withDelay, withRepeat, withSequence, withTiming } from 'react-native-reanimated';
import { VideoView, useVideoPlayer } from 'expo-video';
import { C, R, S, shadow } from '@/theme';
import { FUN_FACTS } from '@/data/fes';
import { Button, Counter, T } from './ui';
import { balance, useStore } from '@/store';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import type { VideoPlayer } from 'expo-video';

/** Keep the four bundled clips ready before a feedback sheet opens. Expo owns release. */
const ClipsContext = createContext<Record<ClipName, VideoPlayer> | null>(null);
const setup = (p:VideoPlayer) => { p.muted=true; p.loop=false; };
export function ClipPlaybackProvider({children}:{children:React.ReactNode}) {
  const clean=useVideoPlayer(CLIPS.clean.src,setup),food=useVideoPlayer(CLIPS.food.src,setup);
  const cup=useVideoPlayer(CLIPS.cup.src,setup),ride=useVideoPlayer(CLIPS.ride.src,setup);
  const players=useMemo(()=>({clean,food,cup,ride}),[clean,food,cup,ride]);
  useEffect(()=>{const subscription=AppState.addEventListener('change',state=>{if(state!=='active')Object.values(players).forEach(p=>p.pause());});return()=>subscription.remove();},[players]);
  return <ClipsContext.Provider value={players}>{children}</ClipsContext.Provider>;
}
export function ClipPlayer({clip='clean',style}:{clip?:ClipName;style?:any}) {
  const players=useContext(ClipsContext);
  return players?<ReadyClip player={players[clip]} clip={clip} style={style}/>:<LocalClip clip={clip} style={style}/>;
}
function LocalClip({clip,style}:{clip:ClipName;style?:any}) {
  const player=useVideoPlayer(CLIPS[clip].src,setup);
  return <ReadyClip player={player} clip={clip} style={style}/>;
}
function ReadyClip({player,clip,style}:{player:VideoPlayer;clip:ClipName;style?:any}) {
  const [frame,setFrame]=useState(false);
  useEffect(()=>{setFrame(false);player.currentTime=0;player.play();},[player]);
  // No player calls in cleanup: the owning Expo hook may already have released it.
  return <View style={[{width:'100%',aspectRatio:CLIPS[clip].ratio,backgroundColor:'#F0F5E9'},style]}>
    <VideoView player={player} style={{width:'100%',height:'100%'}} contentFit="contain" nativeControls={false} onFirstFrameRender={()=>setFrame(true)} />
    {!frame&&<Image pointerEvents="none" source={POSES[clip==='cup'?'coffee':clip==='ride'?'run':clip==='food'?'heart':'cheer'].src} resizeMode="contain" style={{position:'absolute',width:'100%',height:'100%'}}/>}
  </View>;
}

/** One feedback layout: immediate clip, animated balance, explanations and an explicit close. */
export function CelebrationOverlay({open,points=0,duplicate,pending,note,headline,tileLabel,tileValue,clip='clean',onClose,onWhy,continueLabel,onContinue}:{
  open:boolean;points?:number;duplicate?:boolean;pending?:boolean;note?:string;headline?:string;
  tileLabel?:string;tileValue?:string;clip?:ClipName;onClose:()=>void;onWhy?:()=>void;continueLabel?:string;onContinue?:()=>void;
}) {
  const t=useT(),localize=useLocalize(),{height,width}=useWindowDimensions(),insets=useSafeAreaInsets();
  const total=useStore(balance),color=clip==='food'?C.food:clip==='cup'?C.reuse:clip==='ride'?C.mobility:C.clean;
  if(!open)return null;
  const earned=duplicate?0:points;
  return <Modal visible transparent animationType="none" onRequestClose={onClose}>
    <View style={{flex:1,backgroundColor:'rgba(15,20,15,0.66)',justifyContent:'center',alignItems:'center',paddingHorizontal:16,paddingTop:insets.top+12,paddingBottom:insets.bottom+12}}>
      <View style={[{width:Math.min(width-32,440),maxHeight:height-insets.top-insets.bottom-24,backgroundColor:'#fff',borderRadius:24,overflow:'hidden'},shadow(3)]}>
        <ScrollView bounces={false} contentContainerStyle={{paddingBottom:16}}>
          <ClipPlayer clip={clip} style={{height:Math.min(220,height*0.29),aspectRatio:undefined}}/>
          <View style={{paddingHorizontal:20,gap:14,paddingTop:14}}>
            <Text style={[T.h2,{textAlign:'center'}]}>{localize(headline??(duplicate?t('components.celebration.already'):earned>0?t('components.celebration.great'):t('components.celebration.saved')))}</Text>
            <View style={{flexDirection:'row',gap:10}}>
              <View style={{flex:1,backgroundColor:color+'14',padding:12,borderRadius:16,alignItems:'center'}}><Text style={T.small}>{t('updates.pointsAction')}</Text><View style={{flexDirection:'row',alignItems:'center'}}><Text style={{fontSize:30,fontWeight:'900',color}}>+</Text><Counter value={earned} style={{fontSize:30,fontWeight:'900',color}}/></View></View>
              <View style={{flex:1,backgroundColor:C.bg,padding:12,borderRadius:16,alignItems:'center'}}><Text style={T.small}>{t('updates.balance')}</Text><Counter value={total} style={{fontSize:30,fontWeight:'900',color:C.ink}}/></View>
            </View>
            {!!tileValue&&<View style={{alignItems:'center'}}><Text style={T.small}>{tileLabel}</Text><Text style={T.h2}>{tileValue}</Text></View>}
            {!!note?<Text style={[T.body,{textAlign:'center'}]}>{localize(note)}</Text>:pending?<Text style={[T.body,{textAlign:'center'}]}>{t('components.celebration.pending')}</Text>:duplicate?<Text style={[T.body,{textAlign:'center'}]}>{t('components.celebration.once')}</Text>:null}
          </View>
        </ScrollView>
        <View style={{padding:16,gap:8,borderTopWidth:1,borderColor:C.line}}>
          {onWhy&&<Button label={t('why.title')} color={color} variant="soft" onPress={onWhy}/>}
          {onContinue&&<Button label={continueLabel||t('common.next')} color={color} onPress={onContinue}/>}
          <Button label={t('components.common.close')} color={color} variant={onContinue?'ghost':'solid'} onPress={onClose}/>
        </View>
      </View>
    </View>
  </Modal>;
}
